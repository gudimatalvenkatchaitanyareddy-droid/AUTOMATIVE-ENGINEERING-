---
layout: post
title: "Welcome to Automotive Engineering"
date: 2025-08-27
---

Our site focuses on automotive technology and design. Check out these featured images:

![Electric Vehicle](assets/images/car1.jpg)
![Hybrid Car](assets/images/car2.jpg)
![Engine Design](assets/images/engine.jpg)
![Safety Innovations](assets/images/safety.jpg)
